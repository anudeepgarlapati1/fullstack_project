package com.campus.internshiptracker.config;

import com.campus.internshiptracker.model.User;
import com.campus.internshiptracker.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    public DataLoader(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Create Admin User
        if (!userRepository.existsByEmail("admin@example.com")) {
            User admin = new User();
            admin.setName("Admin User");
            admin.setEmail("admin@example.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            userRepository.save(admin);
            System.out.println("✅ Admin user created - Email: admin@example.com, Password: admin123");
        }
        
        // Create Student User
        if (!userRepository.existsByEmail("student@example.com")) {
            User student = new User();
            student.setName("Student User");
            student.setEmail("student@example.com");
            student.setPassword(passwordEncoder.encode("student123"));
            student.setRole(User.Role.STUDENT);
            userRepository.save(student);
            System.out.println("✅ Student user created - Email: student@example.com, Password: student123");
        }
    }
}