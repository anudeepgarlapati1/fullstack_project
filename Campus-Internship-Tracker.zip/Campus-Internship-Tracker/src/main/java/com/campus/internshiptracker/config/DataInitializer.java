package com.campus.internshiptracker.config;

import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.model.User;
import com.campus.internshiptracker.repository.InternshipRepository;
import com.campus.internshiptracker.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import java.time.LocalDate;

@Component
public class DataInitializer implements CommandLineRunner {
    
    private final UserRepository userRepository;
    private final InternshipRepository internshipRepository;
    private final PasswordEncoder passwordEncoder;
    
    public DataInitializer(UserRepository userRepository, InternshipRepository internshipRepository, 
                          PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.internshipRepository = internshipRepository;
        this.passwordEncoder = passwordEncoder;
    }
    
    @Override
    public void run(String... args) throws Exception {
        // Create Admin
        if (!userRepository.existsByEmail("admin@campus.com")) {
            User admin = new User();
            admin.setName("Admin User");
            admin.setEmail("admin@campus.com");
            admin.setPassword(passwordEncoder.encode("admin123"));
            admin.setRole(User.Role.ADMIN);
            userRepository.save(admin);
            System.out.println("✅ Admin created: admin@campus.com / admin123");
        }
        
        // Create Student
        if (!userRepository.existsByEmail("student@campus.com")) {
            User student = new User();
            student.setName("Student User");
            student.setEmail("student@campus.com");
            student.setPassword(passwordEncoder.encode("student123"));
            student.setRole(User.Role.STUDENT);
            userRepository.save(student);
            System.out.println("✅ Student created: student@campus.com / student123");
        }
        
        // Create Sample Internships
        if (internshipRepository.count() == 0) {
            Internship intern1 = new Internship();
            intern1.setTitle("Software Development Intern");
            intern1.setCompany("Tech Corp");
            intern1.setDescription("Looking for passionate software developers...");
            intern1.setLocation("Remote");
            intern1.setDeadline(LocalDate.now().plusDays(30));
            internshipRepository.save(intern1);
            
            Internship intern2 = new Internship();
            intern2.setTitle("Data Science Intern");
            intern2.setCompany("Data Analytics Inc");
            intern2.setDescription("Work on real-world data problems...");
            intern2.setLocation("New York");
            intern2.setDeadline(LocalDate.now().plusDays(20));
            internshipRepository.save(intern2);
            
            Internship intern3 = new Internship();
            intern3.setTitle("Marketing Intern");
            intern3.setCompany("Marketing Pro");
            intern3.setDescription("Learn digital marketing strategies...");
            intern3.setLocation("San Francisco");
            intern3.setDeadline(LocalDate.now().plusDays(15));
            internshipRepository.save(intern3);
            
            System.out.println("✅ 3 Sample internships created");
        }
        
        System.out.println("========================================");
        System.out.println("Demo Credentials:");
        System.out.println("Admin - Email: admin@campus.com, Password: admin123");
        System.out.println("Student - Email: student@campus.com, Password: student123");
        System.out.println("========================================");
    }
}