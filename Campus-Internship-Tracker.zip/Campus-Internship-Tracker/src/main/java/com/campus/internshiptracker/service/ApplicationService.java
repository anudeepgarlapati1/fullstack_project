package com.campus.internshiptracker.service;

import com.campus.internshiptracker.model.Application;
import com.campus.internshiptracker.model.Application.ApplicationStatus;
import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.model.User;
import com.campus.internshiptracker.repository.ApplicationRepository;
import com.campus.internshiptracker.repository.InternshipRepository;
import com.campus.internshiptracker.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ApplicationService {
    
    private final ApplicationRepository applicationRepository;
    private final UserRepository userRepository;
    private final InternshipRepository internshipRepository;
    
    public ApplicationService(ApplicationRepository applicationRepository, 
                             UserRepository userRepository, 
                             InternshipRepository internshipRepository) {
        this.applicationRepository = applicationRepository;
        this.userRepository = userRepository;
        this.internshipRepository = internshipRepository;
    }
    
    public Application applyForInternship(Long studentId, Long internshipId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        
        Internship internship = internshipRepository.findById(internshipId)
                .orElseThrow(() -> new RuntimeException("Internship not found with id: " + internshipId));
        
        Optional<Application> existingApplication = applicationRepository
                .findByStudentAndInternship(studentId, internshipId);
        
        if (existingApplication.isPresent()) {
            throw new RuntimeException("You have already applied for this internship");
        }
        
        Application application = new Application(student, internship);
        return applicationRepository.save(application);
    }
    
    public List<Application> getStudentApplications(Long studentId) {
        User student = userRepository.findById(studentId)
                .orElseThrow(() -> new RuntimeException("Student not found with id: " + studentId));
        return applicationRepository.findByStudent(student);
    }
    
    public List<Application> getInternshipApplications(Long internshipId) {
        Internship internship = internshipRepository.findById(internshipId)
                .orElseThrow(() -> new RuntimeException("Internship not found with id: " + internshipId));
        return applicationRepository.findByInternship(internship);
    }
    
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }
    
    public Application updateApplicationStatus(Long applicationId, ApplicationStatus status) {
        return applicationRepository.findById(applicationId)
                .map(application -> {
                    application.setStatus(status);
                    return applicationRepository.save(application);
                })
                .orElseThrow(() -> new RuntimeException("Application not found with id: " + applicationId));
    }
    
    public Long getApplicationCountByInternship(Long internshipId) {
        return applicationRepository.countByInternshipId(internshipId);
    }
    
    public Long getApplicationCountByStatus(ApplicationStatus status) {
        return applicationRepository.countByStatus(status);
    }
    
    public List<Object[]> getApplicationStats() {
        return applicationRepository.countByStatusGroupBy();
    }
}
