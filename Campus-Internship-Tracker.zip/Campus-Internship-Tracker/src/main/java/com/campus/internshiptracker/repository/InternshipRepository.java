package com.campus.internshiptracker.repository;

import com.campus.internshiptracker.model.Internship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface InternshipRepository extends JpaRepository<Internship, Long> {
    
    @Query("SELECT i FROM Internship i WHERE i.deadline >= :currentDate ORDER BY i.deadline ASC")
    List<Internship> findActiveInternships(LocalDate currentDate);
    
    @Query("SELECT i FROM Internship i WHERE i.deadline < :currentDate ORDER BY i.deadline DESC")
    List<Internship> findExpiredInternships(LocalDate currentDate);
    
    List<Internship> findByCompanyContainingIgnoreCase(String company);
    
    List<Internship> findByLocationContainingIgnoreCase(String location);
}
