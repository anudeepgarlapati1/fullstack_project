package com.campus.internshiptracker.controller;

import com.campus.internshiptracker.model.Application;
import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.repository.ApplicationRepository;
import com.campus.internshiptracker.repository.InternshipRepository;
import com.campus.internshiptracker.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {
    
    private final InternshipRepository internshipRepository;
    private final ApplicationRepository applicationRepository;
    private final UserRepository userRepository;
    
    public AdminController(InternshipRepository internshipRepository, 
                          ApplicationRepository applicationRepository,
                          UserRepository userRepository) {
        this.internshipRepository = internshipRepository;
        this.applicationRepository = applicationRepository;
        this.userRepository = userRepository;
    }
    
    @GetMapping("/stats")
    public Map<String, Object> getStats() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalInternships", internshipRepository.count());
        stats.put("totalApplications", applicationRepository.count());
        stats.put("totalStudents", userRepository.findAll().stream()
                .filter(u -> u.getRole().name().equals("STUDENT")).count());
        stats.put("pendingApplications", applicationRepository.countByStatus(Application.ApplicationStatus.PENDING));
        stats.put("approvedApplications", applicationRepository.countByStatus(Application.ApplicationStatus.APPROVED));
        stats.put("rejectedApplications", applicationRepository.countByStatus(Application.ApplicationStatus.REJECTED));
        return stats;
    }
    
    @GetMapping("/applications")
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }
}