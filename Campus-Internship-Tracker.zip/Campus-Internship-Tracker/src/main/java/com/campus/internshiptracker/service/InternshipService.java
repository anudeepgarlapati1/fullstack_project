package com.campus.internshiptracker.service;

import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.repository.InternshipRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
public class InternshipService {
    
    private final InternshipRepository internshipRepository;
    
    public InternshipService(InternshipRepository internshipRepository) {
        this.internshipRepository = internshipRepository;
    }
    
    public List<Internship> getAllInternships() {
        return internshipRepository.findAll();
    }
    
    public List<Internship> getActiveInternships() {
        return internshipRepository.findActiveInternships(LocalDate.now());
    }
    
    public Optional<Internship> getInternshipById(Long id) {
        return internshipRepository.findById(id);
    }
    
    public Internship createInternship(Internship internship) {
        return internshipRepository.save(internship);
    }
    
    public Internship updateInternship(Long id, Internship internshipDetails) {
        return internshipRepository.findById(id)
                .map(internship -> {
                    internship.setTitle(internshipDetails.getTitle());
                    internship.setCompany(internshipDetails.getCompany());
                    internship.setDescription(internshipDetails.getDescription());
                    internship.setLocation(internshipDetails.getLocation());
                    internship.setDeadline(internshipDetails.getDeadline());
                    return internshipRepository.save(internship);
                })
                .orElseThrow(() -> new RuntimeException("Internship not found with id: " + id));
    }
    
    public void deleteInternship(Long id) {
        if (!internshipRepository.existsById(id)) {
            throw new RuntimeException("Internship not found with id: " + id);
        }
        internshipRepository.deleteById(id);
    }
    
    public List<Internship> searchInternshipsByCompany(String company) {
        return internshipRepository.findByCompanyContainingIgnoreCase(company);
    }
    
    public List<Internship> searchInternshipsByLocation(String location) {
        return internshipRepository.findByLocationContainingIgnoreCase(location);
    }
}
