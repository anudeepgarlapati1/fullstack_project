package com.campus.internshiptracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternshipTrackerApplication {
    public static void main(String[] args) {
        SpringApplication.run(InternshipTrackerApplication.class, args);
        System.out.println("========================================");
        System.out.println("Campus Internship Tracker Started!");
        System.out.println("Access at: http://localhost:8080");
        System.out.println("========================================");
    }
}