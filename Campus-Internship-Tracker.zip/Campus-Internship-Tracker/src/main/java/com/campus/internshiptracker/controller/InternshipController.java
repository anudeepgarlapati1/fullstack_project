package com.campus.internshiptracker.controller;

import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.repository.InternshipRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/internships")
public class InternshipController {
    
    private final InternshipRepository internshipRepository;
    
    public InternshipController(InternshipRepository internshipRepository) {
        this.internshipRepository = internshipRepository;
    }
    
    @GetMapping
    public List<Internship> getAllInternships() {
        return internshipRepository.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Internship> getInternshipById(@PathVariable Long id) {
        return internshipRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Internship> createInternship(@RequestBody Internship internship) {
        return ResponseEntity.status(HttpStatus.CREATED).body(internshipRepository.save(internship));
    }
    
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Internship> updateInternship(@PathVariable Long id, @RequestBody Internship internship) {
        if (!internshipRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        internship.setId(id);
        return ResponseEntity.ok(internshipRepository.save(internship));
    }
    
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteInternship(@PathVariable Long id) {
        if (!internshipRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        internshipRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}