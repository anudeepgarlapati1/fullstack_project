package com.campus.internshiptracker.repository;

import com.campus.internshiptracker.model.Application;
import com.campus.internshiptracker.model.User;
import com.campus.internshiptracker.model.Internship;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByStudent(User student);
    List<Application> findByInternship(Internship internship);
    Optional<Application> findByStudentAndInternship(User student, Internship internship);
    long countByStatus(Application.ApplicationStatus status);
}