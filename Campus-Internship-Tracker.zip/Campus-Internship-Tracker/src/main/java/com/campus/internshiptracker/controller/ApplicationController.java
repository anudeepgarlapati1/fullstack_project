package com.campus.internshiptracker.controller;

import com.campus.internshiptracker.model.Application;
import com.campus.internshiptracker.model.Internship;
import com.campus.internshiptracker.model.User;
import com.campus.internshiptracker.repository.ApplicationRepository;
import com.campus.internshiptracker.repository.InternshipRepository;
import com.campus.internshiptracker.repository.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/applications")
public class ApplicationController {
    
    private final ApplicationRepository applicationRepository;
    private final InternshipRepository internshipRepository;
    private final UserRepository userRepository;
    
    public ApplicationController(ApplicationRepository applicationRepository, 
                                 InternshipRepository internshipRepository,
                                 UserRepository userRepository) {
        this.applicationRepository = applicationRepository;
        this.internshipRepository = internshipRepository;
        this.userRepository = userRepository;
    }
    
    @PostMapping("/apply/{internshipId}")
    public ResponseEntity<?> applyForInternship(@PathVariable Long internshipId, 
                                                 @AuthenticationPrincipal UserDetails userDetails) {
        User student = userRepository.findByEmail(userDetails.getUsername()).get();
        Internship internship = internshipRepository.findById(internshipId)
                .orElseThrow(() -> new RuntimeException("Internship not found"));
        
        if (applicationRepository.findByStudentAndInternship(student, internship).isPresent()) {
            return ResponseEntity.badRequest().body("Already applied for this internship");
        }
        
        Application application = new Application();
        application.setStudent(student);
        application.setInternship(internship);
        
        return ResponseEntity.status(HttpStatus.CREATED).body(applicationRepository.save(application));
    }
    
    @GetMapping("/my-applications")
    public List<Application> getMyApplications(@AuthenticationPrincipal UserDetails userDetails) {
        User student = userRepository.findByEmail(userDetails.getUsername()).get();
        return applicationRepository.findByStudent(student);
    }
    
    @GetMapping("/all")
    @PreAuthorize("hasRole('ADMIN')")
    public List<Application> getAllApplications() {
        return applicationRepository.findAll();
    }
    
    @PutMapping("/{applicationId}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Application> updateApplicationStatus(@PathVariable Long applicationId, 
                                                                @RequestParam String status) {
        Application application = applicationRepository.findById(applicationId)
                .orElseThrow(() -> new RuntimeException("Application not found"));
        
        application.setStatus(Application.ApplicationStatus.valueOf(status.toUpperCase()));
        return ResponseEntity.ok(applicationRepository.save(application));
    }
}