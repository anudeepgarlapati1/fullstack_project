// Authentication utilities
export class AuthManager {
    constructor() {
        this.token = localStorage.getItem('token');
        this.user = JSON.parse(localStorage.getItem('user') || 'null');
        this.updateUI();
    }
    
    login(token, user) {
        this.token = token;
        this.user = user;
        localStorage.setItem('token', token);
        localStorage.setItem('user', JSON.stringify(user));
        this.updateUI();
    }
    
    logout() {
        this.token = null;
        this.user = null;
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        this.updateUI();
        window.location.href = 'index.html';
    }
    
    isAuthenticated() {
        return !!this.token;
    }
    
    isAdmin() {
        return this.user && this.user.role === 'ADMIN';
    }
    
    isStudent() {
        return this.user && this.user.role === 'STUDENT';
    }
    
    getCurrentUser() {
        return this.user;
    }
    
    getToken() {
        return this.token;
    }
    
    updateUI() {
        const loginNavItem = document.getElementById('loginNavItem');
        const registerNavItem = document.getElementById('registerNavItem');
        const userDropdown = document.getElementById('userDropdown');
        const userName = document.getElementById('userName');
        const studentDashboardLink = document.getElementById('studentDashboardLink');
        const adminDashboardLink = document.getElementById('adminDashboardLink');
        
        if (this.isAuthenticated()) {
            // Show user dropdown, hide login/register
            if (loginNavItem) loginNavItem.style.display = 'none';
            if (registerNavItem) registerNavItem.style.display = 'none';
            if (userDropdown) userDropdown.style.display = 'block';
            if (userName) userName.textContent = this.user.name;
            
            // Show appropriate dashboard link
            if (studentDashboardLink) {
                studentDropdownLink.style.display = this.isStudent() ? 'block' : 'none';
            }
            if (adminDashboardLink) {
                adminDashboardLink.style.display = this.isAdmin() ? 'block' : 'none';
            }
        } else {
            // Show login/register, hide user dropdown
            if (loginNavItem) loginNavItem.style.display = 'block';
            if (registerNavItem) registerNavItem.style.display = 'block';
            if (userDropdown) userDropdown.style.display = 'none';
        }
    }
    
    // Check if user has access to current page
    checkPageAccess() {
        const currentPath = window.location.pathname;
        const currentPage = currentPath.split('/').pop();
        
        if (currentPage === 'admin-dashboard.html' && !this.isAdmin()) {
            window.location.href = 'login.html';
            return false;
        }
        
        if (currentPage === 'student-dashboard.html' && !this.isStudent()) {
            window.location.href = 'login.html';
            return false;
        }
        
        return true;
    }
}

// Global auth manager instance
export const authManager = new AuthManager();

// Logout function for global use
export function logout() {
    authManager.logout();
}

// Form validation utilities
export function validateForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return false;
    
    const inputs = form.querySelectorAll('input[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('is-invalid');
            isValid = false;
        } else {
            input.classList.remove('is-invalid');
        }
        
        // Email validation
        if (input.type === 'email' && input.value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(input.value)) {
                input.classList.add('is-invalid');
                isValid = false;
            }
        }
        
        // Password confirmation
        if (input.id === 'confirmPassword') {
            const password = document.getElementById('password').value;
            if (input.value !== password) {
                input.classList.add('is-invalid');
                isValid = false;
            }
        }
    });
    
    return isValid;
}

// Clear form validation
export function clearFormValidation(formId) {
    const form = document.getElementById(formId);
    if (!form) return;
    
    const inputs = form.querySelectorAll('.is-invalid');
    inputs.forEach(input => input.classList.remove('is-invalid'));
}

// Initialize auth on page load
document.addEventListener('DOMContentLoaded', () => {
    authManager.checkPageAccess();
});
