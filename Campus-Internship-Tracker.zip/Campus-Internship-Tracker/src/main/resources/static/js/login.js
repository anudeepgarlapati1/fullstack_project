import { authAPI } from './api.js';
import { authManager, validateForm, clearFormValidation } from './auth.js';
import { showAlert } from './api.js';

document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (!validateForm('loginForm')) {
                return;
            }
            
            const formData = new FormData(loginForm);
            const credentials = {
                email: formData.get('email'),
                password: formData.get('password')
            };
            
            try {
                const response = await authAPI.login(credentials);
                authManager.login(response.token, response);
                
                showAlert('Login successful!', 'success');
                
                // Redirect based on role
                setTimeout(() => {
                    if (response.role === 'ADMIN') {
                        window.location.href = 'admin-dashboard.html';
                    } else {
                        window.location.href = 'student-dashboard.html';
                    }
                }, 1000);
                
            } catch (error) {
                showAlert('Login failed: ' + error.message, 'danger');
                clearFormValidation('loginForm');
            }
        });
        
        // Clear validation on input
        const inputs = loginForm.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                input.classList.remove('is-invalid');
            });
        });
    }
});
