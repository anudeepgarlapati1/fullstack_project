import { authAPI } from './api.js';
import { authManager, validateForm, clearFormValidation } from './auth.js';
import { showAlert } from './api.js';

document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            if (!validateForm('registerForm')) {
                return;
            }
            
            const formData = new FormData(registerForm);
            const userData = {
                name: formData.get('name'),
                email: formData.get('email'),
                password: formData.get('password')
            };
            
            try {
                await authAPI.register(userData);
                showAlert('Registration successful! Please login.', 'success');
                
                // Redirect to login page after successful registration
                setTimeout(() => {
                    window.location.href = 'login.html';
                }, 1500);
                
            } catch (error) {
                showAlert('Registration failed: ' + error.message, 'danger');
                clearFormValidation('registerForm');
            }
        });
        
        // Clear validation on input
        const inputs = registerForm.querySelectorAll('input');
        inputs.forEach(input => {
            input.addEventListener('input', () => {
                input.classList.remove('is-invalid');
                
                // Validate password confirmation in real-time
                if (input.id === 'confirmPassword') {
                    const password = document.getElementById('password').value;
                    if (input.value !== password) {
                        input.classList.add('is-invalid');
                    }
                }
            });
        });
    }
});
