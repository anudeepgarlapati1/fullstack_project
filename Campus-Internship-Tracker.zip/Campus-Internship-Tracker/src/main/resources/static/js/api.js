// API Configuration
const API_BASE_URL = 'http://localhost:8080/api';

// Generic API request function
async function apiRequest(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    const defaultHeaders = {
        'Content-Type': 'application/json',
    };
    
    // Add auth token if available
    const token = localStorage.getItem('token');
    if (token) {
        defaultHeaders['Authorization'] = `Bearer ${token}`;
    }
    
    const config = {
        headers: defaultHeaders,
        ...options,
        headers: {
            ...defaultHeaders,
            ...options.headers,
        },
    };
    
    try {
        const response = await fetch(url, config);
        
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('API Request Error:', error);
        throw error;
    }
}

// Authentication API
export const authAPI = {
    login: (credentials) => apiRequest('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
    }),
    
    register: (userData) => apiRequest('/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
    }),
    
    getCurrentUser: () => apiRequest('/auth/me'),
};

// Internship API
export const internshipAPI = {
    getAll: () => apiRequest('/internships/all'),
    getActive: () => apiRequest('/internships/active'),
    getById: (id) => apiRequest(`/internships/${id}`),
    create: (data) => apiRequest('/internships', {
        method: 'POST',
        body: JSON.stringify(data),
    }),
    update: (id, data) => apiRequest(`/internships/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
    }),
    delete: (id) => apiRequest(`/internships/${id}`, {
        method: 'DELETE',
    }),
    searchByCompany: (company) => apiRequest(`/internships/search/company?company=${company}`),
    searchByLocation: (location) => apiRequest(`/internships/search/location?location=${location}`),
};

// Application API
export const applicationAPI = {
    apply: (internshipId) => apiRequest(`/applications/apply/${internshipId}`, {
        method: 'POST',
    }),
    getMyApplications: () => apiRequest('/applications/my-applications'),
    getInternshipApplications: (internshipId) => apiRequest(`/applications/internship/${internshipId}`),
    getAll: () => apiRequest('/applications/all'),
    updateStatus: (applicationId, status) => apiRequest(`/applications/${applicationId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status }),
    }),
    getStats: () => apiRequest('/applications/stats'),
    getApplicationCount: (internshipId) => apiRequest(`/applications/internship/${internshipId}/count`),
};

// Admin API
export const adminAPI = {
    getDashboardStats: () => apiRequest('/admin/dashboard'),
    getApplicationReport: () => apiRequest('/admin/reports/applications'),
    getInternshipReport: () => apiRequest('/admin/reports/internships'),
};

// Utility functions
export const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
};

export const formatDateTime = (dateString) => {
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
};

export const getStatusBadgeClass = (status) => {
    switch (status.toLowerCase()) {
        case 'pending':
            return 'badge-pending';
        case 'approved':
            return 'badge-approved';
        case 'rejected':
            return 'badge-rejected';
        default:
            return 'bg-secondary';
    }
};

export const showAlert = (message, type = 'info') => {
    const alertContainer = document.getElementById('alertContainer');
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertContainer.appendChild(alertDiv);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 5000);
};

export const showLoadingSpinner = (containerId) => {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `
            <div class="loading-spinner">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <p class="mt-2">Loading...</p>
            </div>
        `;
    }
};

export const hideLoadingSpinner = (containerId, content = '') => {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = content;
    }
};
