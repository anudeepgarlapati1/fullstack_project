import { internshipAPI, applicationAPI } from './api.js';
import { authManager } from './auth.js';

document.addEventListener('DOMContentLoaded', async () => {
    // Update navigation based on auth status
    authManager.updateUI();
    
    // Load statistics for homepage
    await loadStatistics();
});

async function loadStatistics() {
    try {
        // Get all internships
        const internships = await internshipAPI.getAll();
        const activeInternships = internships.filter(i => new Date(i.deadline) >= new Date());
        
        // Get application stats
        const appStats = await applicationAPI.getStats();
        
        // Update statistics
        document.getElementById('totalInternships').textContent = activeInternships.length;
        document.getElementById('totalApplications').textContent = appStats.TOTAL || 0;
        
        // Mock data for demo purposes
        document.getElementById('partnerCompanies').textContent = '25';
        document.getElementById('successRate').textContent = '78%';
        
    } catch (error) {
        console.error('Failed to load statistics:', error);
        // Set default values if API fails
        document.getElementById('totalInternships').textContent = '0';
        document.getElementById('totalApplications').textContent = '0';
        document.getElementById('partnerCompanies').textContent = '0';
        document.getElementById('successRate').textContent = '0%';
    }
}
