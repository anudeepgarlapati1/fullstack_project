@REM ----------------------------------------------------------------------------
@REM Licensed to the Apache Software Foundation (ASF) under one
@REM or more contributor license agreements.  See the NOTICE file
@REM distributed with this work for additional information
@REM regarding copyright ownership.  The ASF licenses this file to you under
@REM the Apache License, Version 2.0 (the "License"); you may not use this file
@REM except in compliance with the License.  You may obtain a copy of the License at
@REM
@REM    http://www.apache.org/licenses/LICENSE-2.0
@REM
@REM Unless required by applicable law or agreed to in writing, software
@REM distributed under the License is distributed on an "AS IS" BASIS,
@REM WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
@REM See the License for the specific language governing permissions and
@REM limitations under the License.
@REM ----------------------------------------------------------------------------

@REM ----------------------------------------------------------------------------
@REM Maven Start Up Batch script, adapted from the Maven Wrapper shell script
@REM Required ENV vars:
@REM ------------------
@REM   JAVA_HOME - location of a JDK home dir
@REM   MAVEN_PROJECTBASEDIR - base directory for Maven projects
@REM   MAVEN_OPTS - arguments passed to the Java VM
@REM
@REM Optional ENV vars
@REM   MAVEN_SKIP_RC - flag to disable loading of mavenrc files
@REM   MAVEN_BATCH_ECHO - set to 'on' to enable batch echoing
@REM   MAVEN_BATCH_PAUSE - set to 'on' to pause the script at the end
@REM   MAVEN_DEBUG - set to 'on' to enable debug output
@REM   MAVEN_MULTI_MODULE_PROJECT - set to 'on' to enable module artifact support
@REM   MAVEN_REACTOR_MODULE_PLATFORM - set to 'on' to enable reactor module platform support
@REM ----------------------------------------------------------------------------

@set ERROR_CODE=0

@setlocal enabledelayedexpansion
@set "MAVEN_PROJECTBASEDIR=%~dp0"

if exist "%MAVEN_PROJECTBASEDIR%\.mvn\jvm.config" (
  set "MAVEN_JVM_EXE=%MAVEN_PROJECTBASEDIR%\.mvn\jvm.config"
)

if exist "%MAVEN_PROJECTBASEDIR%\.mvn\maven.config" (
  set "MAVEN_CONFIG_EXE=%MAVEN_PROJECTBASEDIR%\.mvn\maven.config"
)

@REM ==== START VALIDATION ====
if not defined "%JAVA_HOME%" (
  echo Error: JAVA_HOME is not defined.
  goto :eof
)

if not exist "%JAVA_HOME%\bin\java.exe" (
  echo Error: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
  echo JAVA_HOME = "%JAVA_HOME%"
  goto :eof
)

@REM ==== END VALIDATION ====

set MAVEN_CMD_LINE_ARGS=%*

@REM %MAVEN_SKIP_RC% goto skipRcPreHook

@REM ==== START MAVEN WRAPPER BOOTSTRAP ======================================
call :detectJdkCommand

@REM ==== START MAVEN WRAPPER ======================================
@echo Using Maven Wrapper at "%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.jar"
@echo Maven Wrapper JAR exists: true
@echo Maven Wrapper properties: "%MAVEN_PROJECTBASEDIR%\.mvn\wrapper\maven-wrapper.properties"

@REM ====== LOAD MAVEN WRAPPER PROPERTIES =================================
call :loadMavenWrapperProperties

@REM ====== RESOLVE MAVEN WRAPPER PROPERTIES ==============================
call :resolveMavenWrapperProperties

@REM ====== SET MAVEN WRAPPER CLASSPATH ==============================
call :setMavenWrapperClasspath

@REM ====== EXECUTE MAVEN WRAPPER ==============================
call :executeMaven

@if errorlevel 1 goto error
goto end

:error
set ERROR_CODE=1

:eof
@endlocal & if "%MAVEN_BATCH_PAUSE%" == "on" pause

if "%MAVEN_TERMINATE_CMD%" == "on" exit %ERROR_CODE%

cmd /c exit /b %ERROR_CODE%
