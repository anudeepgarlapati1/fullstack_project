@echo off
echo Testing MySQL connection...
"C:\Program Files\MySQL\MySQL Shell 8.0\bin\mysql.exe" -u root -p2787 -e "SHOW DATABASES;"
echo.
pause
