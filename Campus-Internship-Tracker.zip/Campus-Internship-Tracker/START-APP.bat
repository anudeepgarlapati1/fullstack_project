@echo off
echo ========================================
echo CAMPUS INTERNSHIP TRACKER
echo ========================================
echo.
echo 1. This will open Command Prompt with proper environment
echo 2. Then run the application
echo.
echo Press any key to continue...
pause

REM Open Command Prompt with proper environment
cmd /c "set JAVA_HOME=C:\Program Files\Java\jdk-25 && set PATH=%JAVA_HOME%\bin;%PATH% && cd /d C:\fullstack\Campus-Internship-Tracker && mvn spring-boot:run"
