-- Campus Internship Tracker Database Schema
-- MySQL 8.0+

-- Create database
CREATE DATABASE IF NOT EXISTS internship_tracker 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE internship_tracker;

-- Drop tables if they exist (for clean re-creation)
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS internships;
DROP TABLE IF EXISTS users;

-- Create users table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('STUDENT', 'ADMIN') NOT NULL DEFAULT 'STUDENT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB;

-- Create internships table
CREATE TABLE internships (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    company VARCHAR(100) NOT NULL,
    description TEXT,
    location VARCHAR(200),
    deadline DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_company (company),
    INDEX idx_deadline (deadline),
    INDEX idx_location (location)
) ENGINE=InnoDB;

-- Create applications table
CREATE TABLE applications (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    internship_id BIGINT NOT NULL,
    status ENUM('PENDING', 'APPROVED', 'REJECTED') NOT NULL DEFAULT 'PENDING',
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (internship_id) REFERENCES internships(id) ON DELETE CASCADE,
    
    UNIQUE KEY unique_application (student_id, internship_id),
    INDEX idx_student (student_id),
    INDEX idx_internship (internship_id),
    INDEX idx_status (status)
) ENGINE=InnoDB;

-- Insert default admin user (password: admin123)
INSERT INTO users (name, email, password, role) 
VALUES ('Admin User', 'admin@campus.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN');

-- Insert sample internships for testing
INSERT INTO internships (title, company, description, location, deadline) VALUES
('Software Engineering Intern', 'Google', 'Join our team to work on cutting-edge software projects. You will collaborate with experienced engineers to develop and maintain high-quality software solutions.', 'Mountain View, CA', DATE_ADD(CURRENT_DATE, INTERVAL 30 DAY)),
('Data Science Intern', 'Microsoft', 'Work on real-world data science problems, develop machine learning models, and analyze large datasets to drive business insights.', 'Redmond, WA', DATE_ADD(CURRENT_DATE, INTERVAL 45 DAY)),
('Web Development Intern', 'Amazon', 'Build and maintain web applications using modern frameworks and technologies. Work in an agile environment with cross-functional teams.', 'Seattle, WA', DATE_ADD(CURRENT_DATE, INTERVAL 20 DAY)),
('Mobile App Development Intern', 'Apple', 'Design and develop innovative mobile applications for iOS platform. Work with UX designers and backend engineers to create amazing user experiences.', 'Cupertino, CA', DATE_ADD(CURRENT_DATE, INTERVAL 60 DAY)),
('Cybersecurity Intern', 'IBM', 'Assist in identifying and mitigating security threats, conduct security assessments, and help implement security best practices across enterprise systems.', 'Armonk, NY', DATE_ADD(CURRENT_DATE, INTERVAL 35 DAY)),
('Cloud Computing Intern', 'Oracle', 'Work on cloud infrastructure projects, help design and implement scalable cloud solutions, and learn about enterprise cloud architecture.', 'Austin, TX', DATE_ADD(CURRENT_DATE, INTERVAL 40 DAY)),
('AI/ML Research Intern', 'Meta', 'Conduct research in artificial intelligence and machine learning, develop new algorithms, and work on cutting-edge AI projects.', 'Menlo Park, CA', DATE_ADD(CURRENT_DATE, INTERVAL 55 DAY)),
('DevOps Intern', 'Netflix', 'Learn and implement DevOps practices, work on CI/CD pipelines, and help maintain high-availability streaming infrastructure.', 'Los Gatos, CA', DATE_ADD(CURRENT_DATE, INTERVAL 25 DAY)),
('Database Administration Intern', 'MongoDB', 'Work with database systems, optimize queries, and help manage large-scale data storage solutions.', 'New York, NY', DATE_ADD(CURRENT_DATE, INTERVAL 50 DAY)),
('Frontend Development Intern', 'Adobe', 'Create beautiful and responsive user interfaces using modern frontend technologies. Work closely with UX designers to bring designs to life.', 'San Jose, CA', DATE_ADD(CURRENT_DATE, INTERVAL 15 DAY));

-- Insert sample student users for testing (password: student123)
INSERT INTO users (name, email, password, role) VALUES
('John Smith', 'john.smith@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'STUDENT'),
('Emily Johnson', 'emily.johnson@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'STUDENT'),
('Michael Brown', 'michael.brown@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'STUDENT'),
('Sarah Davis', 'sarah.davis@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'STUDENT'),
('David Wilson', 'david.wilson@university.edu', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'STUDENT');

-- Insert sample applications for testing
INSERT INTO applications (student_id, internship_id, status) VALUES
-- John Smith's applications
(2, 1, 'PENDING'),
(2, 3, 'APPROVED'),
(2, 5, 'REJECTED'),

-- Emily Johnson's applications
(3, 2, 'PENDING'),
(3, 4, 'PENDING'),

-- Michael Brown's applications
(4, 1, 'REJECTED'),
(4, 6, 'APPROVED'),

-- Sarah Davis's applications
(5, 7, 'PENDING'),
(5, 8, 'PENDING'),
(5, 9, 'APPROVED'),

-- David Wilson's applications
(6, 10, 'PENDING');

-- Create views for reporting
CREATE VIEW application_stats AS
SELECT 
    status,
    COUNT(*) as count,
    COUNT(*) * 100.0 / (SELECT COUNT(*) FROM applications) as percentage
FROM applications 
GROUP BY status;

CREATE VIEW internship_stats AS
SELECT 
    i.company,
    COUNT(i.id) as total_internships,
    COUNT(a.id) as total_applications,
    AVG(CASE WHEN a.status = 'APPROVED' THEN 1 ELSE 0 END) * 100 as approval_rate
FROM internships i
LEFT JOIN applications a ON i.id = a.internship_id
GROUP BY i.company
ORDER BY total_internships DESC;

-- Create stored procedures for common operations
DELIMITER //

CREATE PROCEDURE GetStudentApplications(IN student_email VARCHAR(100))
BEGIN
    SELECT 
        a.id,
        a.status,
        a.applied_at,
        i.title,
        i.company,
        i.location,
        i.deadline
    FROM applications a
    JOIN internships i ON a.internship_id = i.id
    JOIN users u ON a.student_id = u.id
    WHERE u.email = student_email
    ORDER BY a.applied_at DESC;
END //

CREATE PROCEDURE GetInternshipApplications(IN internship_id BIGINT)
BEGIN
    SELECT 
        a.id,
        a.status,
        a.applied_at,
        u.name as student_name,
        u.email as student_email
    FROM applications a
    JOIN users u ON a.student_id = u.id
    WHERE a.internship_id = internship_id
    ORDER BY a.applied_at DESC;
END //

CREATE PROCEDURE GetDashboardStats()
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM internships) as total_internships,
        (SELECT COUNT(*) FROM internships WHERE deadline >= CURDATE()) as active_internships,
        (SELECT COUNT(*) FROM applications) as total_applications,
        (SELECT COUNT(*) FROM applications WHERE status = 'PENDING') as pending_applications,
        (SELECT COUNT(*) FROM applications WHERE status = 'APPROVED') as approved_applications,
        (SELECT COUNT(*) FROM applications WHERE status = 'REJECTED') as rejected_applications;
END //

DELIMITER ;

-- Show final database structure
SHOW TABLES;
SHOW COLUMNS FROM users;
SHOW COLUMNS FROM internships;
SHOW COLUMNS FROM applications;
