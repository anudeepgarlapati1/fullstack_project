@echo off
echo ========================================
echo Campus Internship Tracker - Simple Start
echo ========================================
echo.

echo Setting up Java environment...
set JAVA_HOME=C:\Program Files\Java\jdk-25
set PATH=%JAVA_HOME%\bin;%PATH%
echo Java: %JAVA_HOME%
echo.

echo Starting application with system Maven...
mvn spring-boot:run
pause
