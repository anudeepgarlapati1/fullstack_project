@echo off
echo Creating MySQL database...
"C:\Program Files\MySQL\MySQL Shell 8.0\bin\mysql.exe" -u root -p2787 -e "CREATE DATABASE IF NOT EXISTS internship_tracker;"
echo Database created successfully!
echo.
echo Importing schema...
"C:\Program Files\MySQL\MySQL Shell 8.0\bin\mysql.exe" -u root -p2787 internship_tracker < "C:/fullstack/Campus-Internship-Tracker/database/schema.sql"
echo Schema imported successfully!
echo.
echo Database setup complete!
pause
