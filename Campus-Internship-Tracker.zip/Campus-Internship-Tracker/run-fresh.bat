@echo off
echo ========================================
echo Campus Internship Tracker
echo Starting fresh application...
echo ========================================
echo.

echo Setting up Java environment...
set JAVA_HOME=C:\Program Files\Java\jdk-25
set PATH=%JAVA_HOME%\bin;%PATH%
echo Java: %JAVA_HOME%
echo.

echo Cleaning and building project...
call mvn clean compile
if %ERRORLEVEL% neq 0 (
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo Starting Spring Boot application...
call mvn spring-boot:run
pause
