@echo off
echo Setting up environment...
set JAVA_HOME=C:\Program Files\Java\jdk-25
set PATH=%JAVA_HOME%\bin;%PATH%
echo Running Spring Boot application with H2 database (for testing)...
.\mvnw.cmd spring-boot:run -Dspring.profiles.active=h2
pause
