# Campus Internship Tracker

A full-stack web application for managing campus internships, allowing students to browse and apply for internships while administrators manage postings and applications.

## 🚀 Tech Stack

### Backend
- **Java 17** with Spring Boot 3.2.0
- **Spring Security** with JWT authentication
- **Spring Data JPA** with Hibernate
- **MySQL 8.0** database
- **Maven** for dependency management

### Frontend
- **HTML5, CSS3, JavaScript (ES6+)**
- **Bootstrap 5.3** for responsive UI
- **Font Awesome** for icons
- **Vanilla JavaScript** (no frameworks required)

### Features
- 🔐 JWT-based authentication with role-based access control
- 👥 Student and Admin roles
- 📱 Responsive design for all devices
- 📊 Real-time dashboard analytics
- 🔍 Advanced search and filtering
- 📧 Application status tracking
- 📈 Reporting and analytics

## 📋 Prerequisites

- **Java 17** or higher
- **Maven 3.6** or higher
- **MySQL 8.0** or higher
- **Git** for cloning the repository

## 🛠️ Installation & Setup

### 1. Clone the Repository
```bash
git clone <repository-url>
cd Campus-Internship-Tracker
```

### 2. Database Setup

#### Install MySQL (if not already installed)
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install mysql-server

# macOS (using Homebrew)
brew install mysql

# Windows
# Download and install from https://dev.mysql.com/downloads/mysql/
```

#### Start MySQL Service
```bash
# Ubuntu/Debian
sudo systemctl start mysql
sudo systemctl enable mysql

# macOS
brew services start mysql

# Windows
net start mysql
```

#### Create Database and Import Schema
```bash
# Login to MySQL
mysql -u root -p

# Run the schema script
mysql -u root -p < database/schema.sql
```

**Default Credentials:**
- Admin Email: `admin@campus.com`
- Admin Password: `admin123`
- Student Password: `student123` (for all sample student accounts)

### 3. Configure Application

Edit the database configuration in `src/main/resources/application.properties`:

```properties
# Update these values according to your MySQL setup
spring.datasource.url=jdbc:mysql://localhost:3306/internship_tracker?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
spring.datasource.username=root
spring.datasource.password=your_mysql_password
```

### 4. Build and Run the Application

#### Using Maven
```bash
# Build the project
mvn clean install

# Run the application
mvn spring-boot:run
```

#### Or run the JAR directly
```bash
# After building with mvn install
java -jar target/internship-tracker-1.0.0.jar
```

### 5. Access the Application

Once the application starts, you can access it at:

- **Application URL:** http://localhost:8080
- **API Base URL:** http://localhost:8080/api

## 🎯 Usage Guide

### For Students

1. **Register Account:**
   - Visit http://localhost:8080/register.html
   - Fill in your details and create an account

2. **Browse Internships:**
   - Visit http://localhost:8080/internships.html
   - Use filters to find relevant opportunities
   - Click "View Details" to see more information

3. **Apply for Internships:**
   - Login with your credentials
   - Browse available internships
   - Click "Apply Now" on interested positions
   - Track your application status in the dashboard

4. **Student Dashboard:**
   - Visit http://localhost:8080/student-dashboard.html
   - View all your applications
   - Track application status (Pending, Approved, Rejected)

### For Administrators

1. **Login:**
   - Use admin credentials: `admin@campus.com` / `admin123`
   - Visit http://localhost:8080/login.html

2. **Admin Dashboard:**
   - Visit http://localhost:8080/admin-dashboard.html
   - View platform statistics and analytics
   - Manage internships and applications

3. **Manage Internships:**
   - Add new internship postings
   - Edit existing postings
   - Delete expired or irrelevant postings

4. **Manage Applications:**
   - Review student applications
   - Approve or reject applications
   - Generate reports and analytics

## 📁 Project Structure

```
Campus-Internship-Tracker/
├── src/
│   └── main/
│       ├── java/com/campus/internshiptracker/
│       │   ├── controller/          # REST API controllers
│       │   ├── dto/                 # Data transfer objects
│       │   ├── model/               # JPA entities
│       │   ├── repository/          # Spring Data repositories
│       │   ├── security/           # JWT and security configuration
│       │   ├── service/             # Business logic services
│       │   └── InternshipTrackerApplication.java
│       └── resources/
│           ├── application.properties
│           └── static/              # Frontend files
│               ├── css/
│               ├── js/
│               ├── index.html
│               ├── login.html
│               ├── register.html
│               ├── internships.html
│               ├── student-dashboard.html
│               └── admin-dashboard.html
├── database/
│   └── schema.sql                   # Database schema and sample data
├── pom.xml                         # Maven configuration
└── README.md                       # This file
```

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - Student registration
- `GET /api/auth/me` - Get current user info

### Internships
- `GET /api/internships/all` - Get all internships
- `GET /api/internships/active` - Get active internships
- `GET /api/internships/{id}` - Get internship by ID
- `POST /api/internships` - Create internship (Admin only)
- `PUT /api/internships/{id}` - Update internship (Admin only)
- `DELETE /api/internships/{id}` - Delete internship (Admin only)

### Applications
- `POST /api/applications/apply/{internshipId}` - Apply for internship (Student only)
- `GET /api/applications/my-applications` - Get student's applications (Student only)
- `GET /api/applications/all` - Get all applications (Admin only)
- `PUT /api/applications/{id}/status` - Update application status (Admin only)

### Admin
- `GET /api/admin/dashboard` - Get dashboard statistics (Admin only)
- `GET /api/admin/reports/applications` - Get application reports (Admin only)
- `GET /api/admin/reports/internships` - Get internship reports (Admin only)

## 🧪 Testing

### Run Tests
```bash
# Run all tests
mvn test

# Run specific test class
mvn test -Dtest=AuthServiceTest

# Run tests with coverage
mvn clean test jacoco:report
```

### Test Credentials
- **Admin:** admin@campus.com / admin123
- **Students:** john.smith@university.edu / student123

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Ensure MySQL is running
   - Check database credentials in `application.properties`
   - Verify database was created using schema.sql

2. **JWT Token Issues**
   - Clear browser localStorage
   - Check JWT secret in application.properties
   - Ensure token hasn't expired (24 hours by default)

3. **CORS Errors**
   - Check CORS configuration in SecurityConfig.java
   - Ensure frontend is accessing correct port (8080)

4. **Port Already in Use**
   ```bash
   # Find process using port 8080
   netstat -ano | findstr :8080
   
   # Kill the process (Windows)
   taskkill /PID <PID> /F
   
   # Kill the process (Linux/Mac)
   kill -9 <PID>
   ```

### Debug Mode
Enable debug logging by adding to `application.properties`:
```properties
logging.level.com.campus.internshiptracker=DEBUG
logging.level.org.springframework.security=DEBUG
```

## 📊 Database Schema

The application uses three main tables:

1. **users** - Stores user information and roles
2. **internships** - Stores internship postings
3. **applications** - Stores student applications and their status

See `database/schema.sql` for complete schema definition.

## 🔒 Security Features

- **JWT Authentication** with 24-hour expiration
- **Role-based Access Control** (Student/Admin)
- **Password Encryption** using BCrypt
- **CORS Configuration** for cross-origin requests
- **Input Validation** on all API endpoints
- **SQL Injection Prevention** through JPA

## 🚀 Deployment

### Production Configuration

1. **Environment Variables:**
   ```bash
   export DB_URL=jdbc:mysql://your-db-host:3306/internship_tracker
   export DB_USERNAME=your-db-username
   export DB_PASSWORD=your-db-password
   export JWT_SECRET=your-super-secret-jwt-key
   ```

2. **Build for Production:**
   ```bash
   mvn clean package -Pprod
   ```

3. **Run with Production Profile:**
   ```bash
   java -jar -Dspring.profiles.active=prod target/internship-tracker-1.0.0.jar
   ```

### Docker Deployment (Optional)

```dockerfile
# Dockerfile
FROM openjdk:17-jdk-slim
COPY target/internship-tracker-1.0.0.jar app.jar
EXPOSE 8080
ENTRYPOINT ["java", "-jar", "/app.jar"]
```

```bash
# Build and run
docker build -t internship-tracker .
docker run -p 8080:8080 internship-tracker
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Support

For support and questions:
- Create an issue in the repository
- Email: support@campus-tracker.com

## 🎉 Acknowledgments

- Spring Boot team for the amazing framework
- Bootstrap for the UI components
- Font Awesome for the icons
- All contributors who helped build this project
