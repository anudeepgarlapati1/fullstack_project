package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.dto.LoginRequest;
import com.example.model.User;
import com.example.service.AuthService;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    private AuthService service;

    @PostMapping("/login")
    public User login(@RequestBody LoginRequest req) {
        return service.login(req.email, req.password);
    }
}