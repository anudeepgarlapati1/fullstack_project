package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import com.example.model.*;
import com.example.service.ClaimService;

@RestController
@RequestMapping("/claims")
@CrossOrigin(origins = "*")
public class ClaimController {

    @Autowired
    private ClaimService service;

    // 📎 SUBMIT CLAIM WITH FILE UPLOAD
    @PostMapping(consumes = "multipart/form-data")
    public Claim addClaim(
            @RequestParam("policy") String policy,
            @RequestParam("amount") double amount,
            @RequestParam("description") String description,
            @RequestParam("file") MultipartFile file
    ) throws Exception {

        // ✅ Absolute path (fix for 500 error)
        String uploadDir = System.getProperty("user.dir") + "/uploads/";
        File dir = new File(uploadDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        // ✅ Unique file name
        String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

        // ✅ Save file safely
        File destination = new File(uploadDir + fileName);
        file.transferTo(destination);

        System.out.println("File saved at: " + destination.getAbsolutePath());

        // ✅ Save to DB
        Claim claim = new Claim();
        claim.setPolicy(policy);
        claim.setAmount(amount);
        claim.setDescription(description);
        claim.setFileName(fileName);

        return service.addClaim(claim);
    }

    // 📊 GET ALL CLAIMS
    @GetMapping
    public List<Claim> getClaims() {
        return service.getAllClaims();
    }

    // 👨‍💼 ADMIN: UPDATE STATUS
    @PutMapping("/{id}")
    public Claim updateStatus(@PathVariable Long id,
                             @RequestParam ClaimStatus status) {
        return service.updateStatus(id, status);
    }

    // 👁️ VIEW FILE
    @GetMapping("/file/{fileName}")
    public ResponseEntity<byte[]> viewFile(@PathVariable String fileName) throws Exception {

        Path path = Paths.get(System.getProperty("user.dir") + "/uploads/" + fileName);

        if (!Files.exists(path)) {
            return ResponseEntity.notFound().build();
        }

        byte[] file = Files.readAllBytes(path);

        MediaType mediaType;

        if (fileName.toLowerCase().endsWith(".pdf")) {
            mediaType = MediaType.APPLICATION_PDF;
        } else if (fileName.toLowerCase().endsWith(".jpg") || fileName.toLowerCase().endsWith(".jpeg")) {
            mediaType = MediaType.IMAGE_JPEG;
        } else if (fileName.toLowerCase().endsWith(".png")) {
            mediaType = MediaType.IMAGE_PNG;
        } else {
            mediaType = MediaType.APPLICATION_OCTET_STREAM;
        }

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=\"" + fileName + "\"")
                .contentType(mediaType)
                .body(file);
    }

    // ⬇️ DOWNLOAD FILE
    @GetMapping("/download/{fileName}")
    public ResponseEntity<byte[]> downloadFile(@PathVariable String fileName) throws Exception {
        Path path = Paths.get(System.getProperty("user.dir") + "/uploads/" + fileName);

        if (!Files.exists(path)) {
            return ResponseEntity.notFound().build();
        }

        byte[] file = Files.readAllBytes(path);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + fileName)
                .body(file);
    }
}