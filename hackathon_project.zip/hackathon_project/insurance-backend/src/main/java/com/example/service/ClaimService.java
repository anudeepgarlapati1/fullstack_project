package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

import com.example.model.*;
import com.example.repository.ClaimRepository;

@Service
public class ClaimService {

    @Autowired
    private ClaimRepository repo;

    public Claim addClaim(Claim claim) {
        claim.setStatus(ClaimStatus.SUBMITTED);
        return repo.save(claim);
    }

    public List<Claim> getAllClaims() {
        return repo.findAll();
    }

    public Claim updateStatus(Long id, ClaimStatus status) {
        Claim c = repo.findById(id).orElseThrow();
        c.setStatus(status);
        return repo.save(c);
    }
}